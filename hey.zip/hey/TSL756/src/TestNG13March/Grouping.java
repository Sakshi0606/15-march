package TestNG13March;

import org.testng.annotations.Test;
import org.testng.annotations.Test;

public class Grouping  {
  @Test(groups="smoke")
  public void f1() {
	  System.out.println("IN FUN 1 smoke");
  }
  @Test(groups= {"smoke","regression"})
  public void f2() {
	  System.out.println("IN FUN 2 smoke regression");
  }
  @Test(groups="regression")
  public void f3() {
	  System.out.println("IN FUN 3 regression");
  }
  
}
