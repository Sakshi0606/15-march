package TestNG13March;

import org.testng.Assert;
import org.testng.annotations.Test;

import org.testng.annotations.Test;

public class DependsExample {
  @Test
  public void f1() 
  {
	  System.out.println("In Test");
	  Assert.assertTrue(true);
  }
  
  @Test(dependsOnMethods="f1")
  public void f2() 
  {
	  System.out.println("In Test 2");
	  Assert.assertEquals("LNT","LNT");
  }
  
  @Test(dependsOnMethods="f2")
  public void f3() 
  {
	  System.out.println("In Test 3");
	  Assert.assertEquals("LNT","LNT");
  }
  
}
