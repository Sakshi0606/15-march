package dao;
import java.util.ArrayList;
import java.util.List;
import pojo.LoginDetails;

public interface LoginDetailsDAO {

	ArrayList<LoginDetails> getAllLoginDetails();
	
}
