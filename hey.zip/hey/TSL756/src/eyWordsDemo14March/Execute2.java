package eyWordsDemo14March;

import org.testng.annotations.Test;

import util.Base2;
import util.KeyWords;

public class Execute2 extends Base2 {
  @Test
  public void f() {
	  key.openUrl("https://opensource-demo.orangehrmlive.com/");
	  key.type("txtUsername_:name", "admin");
	  key.type("txtPassword_:id", "admin123");
	  key.click("//*[@type='submit']_:xpath");
	  key.click("//*[@id='welcome']_:xpath");
	  key.getScreenShot("Orange");
	  key.click("Logout_:linktext");
  }
}
